//
//  vehicleMode.swift
//  tabTestApp
//
//  Created by James Graver on 9/18/21.
//

import Foundation

struct zvehicle {
    var vehicleid: Int
    var make: String
    var model: String
}
