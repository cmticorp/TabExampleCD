//
//  DisplayCarsViewController.swift
//  tabTestApp
//
//  Created by James Graver on 9/18/21.
//

import UIKit
import Foundation
import CoreData

class DisplayCarsViewController: UITableViewController,  NSFetchedResultsControllerDelegate {
    
    var ls_vehicle: zvehicle = zvehicle.init(vehicleid: 0, make: "", model: "")
    var lt_vehicle: [zvehicle] = []
    var Vehicle: [NSManagedObject] = []
    var controller: NSFetchedResultsController<Inventory>!
    var lv_section: Int = 0
    var lv_objects: Int = 0

    override func viewDidLoad() {
        super.viewDidLoad()
        fetchVehicles()
        // Do any additional setup after loading the view.
    }
    

   
    func fetchVehicles() {
        guard let appDelegate =
          UIApplication.shared.delegate as? AppDelegate else {
            return
        }
        
        let managedContext =
          appDelegate.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<Inventory>(entityName: "Inventory")
        fetchRequest.sortDescriptors = [NSSortDescriptor(key: "vehicleid", ascending: true)]
        controller = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: managedContext, sectionNameKeyPath: nil, cacheName: nil)
        controller.delegate = self
        
        do {
            try controller.performFetch()
        } catch let error as NSError {
          print("Could not fetch. \(error), \(error.userInfo)")
        }
        
        let lv_section = controller.sections?.count
        
        if (lv_section! > 0) {
            print("records found")
        } else {
            print("no records found")
        }
       
     //end of fetch
    }
    
    //table view functions
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
      
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        guard let sections = self.controller?.sections else {
           // fatalError("No sections in fetchedResultsController")
            return 1
        }
        let sectionInfo = sections[section]
        return sectionInfo.numberOfObjects
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: VehicleTableViewCell.reuseidentifier, for: indexPath) as! VehicleTableViewCell

        if (self.controller != nil) {
        guard let object = self.controller?.object(at: indexPath) else {
            fatalError("Attempt to configure cell without a managed object")
            }
            //configure cell with data from core data
            let ls_auto = controller?.object(at: indexPath)
            let lv_vehicleid = Int(ls_auto!.vehicleid)
            cell.vehicleidLbl.text = "Vehicle ID: " + String(lv_vehicleid)
            cell.vehicleModelLbl.text = "Vehicle Model: " + ls_auto!.model!
        }
        return cell
    }
    
//end of class
}
