//
//  CreateVehicleViewController.swift
//  tabTestApp
//
//  Created by James Graver on 9/18/21.
//

import UIKit
import Foundation
import CoreData

class CreateVehicleViewController: UITableViewController {
    
    var ls_vehicle: zvehicle = zvehicle.init(vehicleid: 0, make: "", model: "")
    var Vehicle: [NSManagedObject] = []

    @IBOutlet weak var vehicleid: UITextField!
    @IBOutlet weak var vehmake: UITextField!
    @IBOutlet weak var vehmodel: UITextField!
    
    
    @IBAction func createVehicle(_ sender: Any) {
             ls_vehicle.vehicleid = (vehicleid.text! as NSString).integerValue
             ls_vehicle.make = vehmake.text!
             ls_vehicle.model = vehmodel.text!
              saveVehicleCoreData(lsvehicle: ls_vehicle)
             print("vehicle saved")
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
    }
    

       func saveVehicleCoreData(lsvehicle: zvehicle) {
          guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
              return
          }
        
          let managedContext = appDelegate.persistentContainer.viewContext
        
          let entity = NSEntityDescription.entity(forEntityName: "Inventory", in: managedContext)!
        
        let car = NSManagedObject(entity: entity, insertInto: managedContext)
        
        
        car.setValue(ls_vehicle.vehicleid, forKeyPath: "vehicleid")
        car.setValue(ls_vehicle.make, forKeyPath: "make")
        car.setValue(ls_vehicle.model, forKeyPath: "model")
        
        do{
            try managedContext.save()
            Vehicle.append(car)
        } catch let error as NSError {
            print("Could not save. \(error)")
        }
        
    }
   

}
