//
//  VehicleTableViewCell.swift
//  tabTestApp
//
//  Created by James Graver on 9/18/21.
//

import UIKit

class VehicleTableViewCell: UITableViewCell {
    
    static let reuseidentifier = "vehicleCell"

    @IBOutlet weak var vehicleidLbl: UILabel!    
    @IBOutlet weak var vehicleModelLbl: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
